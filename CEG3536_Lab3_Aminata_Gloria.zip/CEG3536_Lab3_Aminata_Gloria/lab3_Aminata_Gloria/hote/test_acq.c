/* ---------------------------------------------------------------------------
 * test_acq.c — essais sur hôte de l'objet d'acquisition (CEG 3536, lab. 3, L3-C)
 *   make test_acq   (ou : gcc -std=gnu11 -Wall -Wextra -I../Core/Inc
 *                     -o test_acq test_acq.c ../Core/Src/acq.c)
 * acq.c n'accède à aucun registre : un tableau ordinaire remplace le tampon
 * DMA. Mêmes paramètres d'initialisation que main.c.
 * ------------------------------------------------------------------------- */
#include <stdio.h>
#include <stdint.h>
#include "acq.h"

#define N_VOIES 2u
#define N_PAR_VOIE 64u
#define MV_REF 1831
#define C10_REF 250

static volatile uint16_t tampon[N_VOIES * N_PAR_VOIE];
static unsigned echecs, cas;

static void remplir(uint32_t voie, uint16_t brut)
{
    for (uint32_t i = 0u; i < N_PAR_VOIE; i++) tampon[i * N_VOIES + voie] = brut;
}

static void verifier(const char *nom, long obtenu, long attendu)
{
    cas++;
    int ok = (obtenu == attendu);
    if (!ok) echecs++;
    printf("  %-48s obtenu %6ld attendu %6ld : %s\n", nom, obtenu, attendu, ok ? "ok" : "ECHEC");
}

int main(void)
{
    acq_t pot, temp;
    acq_init(&pot, &tampon[0], N_VOIES, 16u, 100, 3300, 0);
    acq_config_filtre(&pot, 2, 3, 0, 100);
    acq_init(&temp, &tampon[1], N_VOIES, 64u, -10000, 10900,
             C10_REF + (MV_REF * 10000) / 10900);

    printf("acq : sizeof(acq_t) = %u octets par instance\n", (unsigned)sizeof(acq_t));

    /* moyenne arrondie */
    for (uint32_t i = 0u; i < 16u; i++) tampon[i * N_VOIES] = (uint16_t)(i & 1u ? 101 : 100);
    verifier("moyenne arrondie (100/101 alternes -> 101)", (long)acq_brut(&pot), 101);

    /* potentiomètre : bornes et zone morte */
    acq_init(&pot, &tampon[0], N_VOIES, 16u, 100, 3300, 0);
    acq_config_filtre(&pot, 2, 3, 0, 100);
    remplir(0u, 0);    verifier("pot en bas (brut 0) -> 0 %", acq_valeur(&pot), 0);
    remplir(0u, 80);   verifier("pot brut 80 (~2 %, zone morte) -> 0 %", acq_valeur(&pot), 0);
    remplir(0u, 2048); verifier("pot au milieu (brut 2048) -> 50 %", acq_valeur(&pot), 50);
    remplir(0u, 2089); verifier("pot +1 point (51 %) : hysteresis -> 50", acq_valeur(&pot), 50);
    remplir(0u, 2130); verifier("pot +2 points (52 %) : hysteresis -> 50", acq_valeur(&pot), 50);
    remplir(0u, 2171); verifier("pot +3 points (53 %) -> 53", acq_valeur(&pot), 53);
    remplir(0u, 4020); verifier("pot brut 4020 (98 %, zone morte) -> 100", acq_valeur(&pot), 100);
    remplir(0u, 4095); verifier("pot en haut (brut 4095) -> 100 %", acq_valeur(&pot), 100);

    /* température : point de référence et pente */
    remplir(1u, (uint16_t)((MV_REF * 4095 + 1650) / 3300));     /* ~1831 mV */
    verifier("temp a 1831 mV -> 25,0 C (250 +/- 1)", acq_valeur(&temp) >= 249 && acq_valeur(&temp) <= 251, 1);
    remplir(1u, (uint16_t)((1777 * 4095 + 1650) / 3300));       /* ~30 °C */
    verifier("temp a 1777 mV -> ~30,0 C (300 +/- 2)", acq_valeur(&temp) >= 298 && acq_valeur(&temp) <= 302, 1);

    /* indépendance des deux instances : la voie 1 ne touche pas la voie 0 */
    remplir(0u, 2048);
    acq_init(&pot, &tampon[0], N_VOIES, 16u, 100, 3300, 0);    /* sans filtre */
    long avant = acq_valeur(&pot);
    acq_init(&temp, &tampon[1], N_VOIES, 64u, -20000, 10900, 0); /* gain change */
    remplir(1u, 100);
    verifier("independance : gain de temp change, pot inchange", acq_valeur(&pot), avant);

    printf("%u cas, %u echec(s) : %s\n", cas, echecs, echecs ? "ECHEC" : "OK");
    return echecs ? 1 : 0;
}
