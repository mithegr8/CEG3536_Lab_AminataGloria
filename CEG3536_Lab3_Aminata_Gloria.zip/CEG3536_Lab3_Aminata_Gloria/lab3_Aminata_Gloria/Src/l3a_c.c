/* ---------------------------------------------------------------------------
 * l3a_c.c — version C de la routine assembleur conservée pour L3-A
 *           (CEG 3536, laboratoire 3)
 *
 * Routine choisie : motor_set_pwm (motor.s, laboratoire 2), réécrite en C
 * avec exactement le même prototype et le même comportement, sans modifier
 * la version assembleur :
 *   - pct > 100 saturé à 100 (cmp / it hi / movhi) ;
 *   - CCR1 = pct x PWM_PLEINE / 100, PWM_PLEINE = ARR + 1 = 200
 *     (mul puis udiv) ;
 *   - retour = valeur écrite dans CCR1 (0 à 200), pas le pourcentage.
 * Comparaison (valeur de retour, TIM1_CCR1, cycles DWT) par bench_l3a.c
 * (commande série b : B,ecarts=0 attendu), puis désassemblage à -O0 et -O2
 * (L3-D). À -O2, GCC remplace la division par 100 par une multiplication
 * par 0x51EB851F suivie d'un décalage (division par une constante).
 * ------------------------------------------------------------------------- */
#include "stm32l552xx.h"
#include "bench_l3a.h"

#define PWM_PCT_MAX 100u
#define PWM_PLEINE  200u        /* = PWM_ARR + 1 (registres_lab2.inc)          */

uint32_t motor_set_pwm_c(uint32_t pct)
{
    uint32_t ccr1;

    if (pct > PWM_PCT_MAX) {
        pct = PWM_PCT_MAX;                          /* saturation              */
    }
    ccr1 = (pct * PWM_PLEINE) / PWM_PCT_MAX;        /* 0 .. 200                */
    TIM1->CCR1 = ccr1;
    return ccr1;                                    /* comme motor.s           */
}
