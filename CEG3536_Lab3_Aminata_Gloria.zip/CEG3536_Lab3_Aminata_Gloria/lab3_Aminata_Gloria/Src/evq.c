/* ---------------------------------------------------------------------------
 * evq.c — file circulaire d'événements (CEG 3536, laboratoire 3, E7)
 *
 * Tableau fixe de EVQ_CAPACITE éléments, indice de tête (lecture), indice de
 * queue (écriture), compteur d'éléments. Débordement : push refusé et compté,
 * la file n'est jamais corrompue (l'élément refusé n'écrase rien).
 * Aucun accès matériel : ce fichier est compilé tel quel sur hôte
 * (hote/Makefile) et sur la cible.
 *
 * Invariants (vérifiés par hote/test_evq.c et la commande série q) :
 *   0 <= nombre <= EVQ_CAPACITE
 *   queue == (tete + nombre) % EVQ_CAPACITE
 *   total - (éléments retirés) == nombre
 * L'enroulement utilise un test d'égalité plutôt que « % » : correct pour
 * toute capacité (pas seulement une puissance de 2) et sans division.
 * ------------------------------------------------------------------------- */
#include "evq.h"

static evq_event_t file[EVQ_CAPACITE];
static uint32_t    tete;          /* prochain élément à lire                   */
static uint32_t    queue;         /* prochaine case à écrire                   */
static uint32_t    nombre;        /* éléments présents                         */
static uint32_t    debordements;  /* push refusés (file pleine)                */
static uint32_t    total;         /* push acceptés depuis evq_init             */

static uint32_t suivant(uint32_t i)
{
    i++;
    return (i == EVQ_CAPACITE) ? 0u : i;     /* enroulement de l'index       */
}

void evq_init(void)
{
    tete = queue = nombre = debordements = total = 0u;
}

bool evq_push(evq_type_t type, uint32_t valeur, uint32_t t_ms)
{
    if (nombre >= EVQ_CAPACITE) {
        debordements++;                       /* compté, rien n'est écrasé    */
        return false;
    }
    file[queue].type   = type;
    file[queue].valeur = valeur;
    file[queue].t_ms   = t_ms;
    queue = suivant(queue);
    nombre++;
    total++;
    return true;
}

bool evq_pop(evq_event_t *e)
{
    if (e == 0 || nombre == 0u) {
        return false;
    }
    *e = file[tete];
    tete = suivant(tete);
    nombre--;
    return true;
}

uint32_t evq_count(void)        { return nombre; }
uint32_t evq_debordements(void) { return debordements; }
uint32_t evq_total(void)        { return total; }
