/* ---------------------------------------------------------------------------
 * acq.c — objet d'acquisition d'une voie analogique (CEG 3536, lab. 3, L3-C)
 *         — VERSION 2
 *
 * Aucun registre : les échantillons viennent d'un tampon mémoire rempli par
 * le DMA (pointeur src passé à l'initialisation). Toutes les opérations en
 * entiers 32 bits.
 *
 * Version 1 : acq_init, acq_brut (moyenne arrondie), acq_mv, acq_valeur
 *             (relation linéaire propre à l'instance). Voir versions/acq_v1.c.
 * Version 2 (changement d'exigence, énoncé 4.6) :
 *   - acq_valeur applique, si acq_config_filtre l'a demandé, une zone morte
 *     aux extrémités puis une hystérésis ;
 *   - la température est moyennée sur 64 échantillons : seul n_moy change à
 *     l'initialisation (main.c), le tampon DMA passe à ADC_N_PAR_VOIE = 64.
 *   Aucun appelant (main.c, fsm.c) ne change ailleurs qu'à l'initialisation.
 *
 * Accès concurrent au tampon DMA : chaque échantillon est un demi-mot aligné,
 * lu en une seule instruction LDRH, donc jamais « à moitié écrit ». La moyenne
 * peut mélanger des échantillons de deux tours consécutifs du tampon, ce qui
 * est sans conséquence pour une moyenne glissante (limite discutée en L3-C).
 * ------------------------------------------------------------------------- */
#include "acq.h"

#define ACQ_PLEINE_ECHELLE 4095
#define ACQ_VREF_MV        3300

void acq_init(acq_t *a, const volatile uint16_t *src, uint32_t pas, uint32_t n_moy,
              int32_t gain_num, int32_t gain_den, int32_t decalage)
{
    a->src = src;
    a->pas = (pas == 0u) ? 1u : pas;
    a->n_moy = (n_moy == 0u) ? 1u : n_moy;
    a->gain_num = gain_num;
    a->gain_den = (gain_den == 0) ? 1 : gain_den;
    a->decalage = decalage;
    a->hysteresis = 0;
    a->zone_morte = 0;
    a->v_min = 0;
    a->v_max = 0;
    a->derniere = 0;
    a->initialisee = 0u;
}

void acq_config_filtre(acq_t *a, int32_t hysteresis, int32_t zone_morte,
                       int32_t v_min, int32_t v_max)
{
    a->hysteresis = hysteresis;
    a->zone_morte = zone_morte;
    a->v_min = v_min;
    a->v_max = v_max;
    a->initialisee = 0u;      /* la prochaine valeur est prise telle quelle   */
}

/* Moyenne arrondie des n_moy échantillons src[0], src[pas], src[2 x pas]...
 * Somme maximale : 64 x 4095 = 262 080, sans risque sur 32 bits.           */
uint32_t acq_brut(const acq_t *a)
{
    uint32_t somme = 0u;
    const volatile uint16_t *p = a->src;
    for (uint32_t i = 0u; i < a->n_moy; i++) {
        somme += *p;
        p += a->pas;
    }
    return (somme + a->n_moy / 2u) / a->n_moy;
}

uint32_t acq_mv(const acq_t *a)
{
    return (acq_brut(a) * ACQ_VREF_MV + ACQ_PLEINE_ECHELLE / 2) / ACQ_PLEINE_ECHELLE;
}

static int32_t ecart_abs(int32_t a, int32_t b)
{
    return (a > b) ? (a - b) : (b - a);
}

/* v = mv x gain_num / gain_den + decalage ; puis (version 2) :
 *   zone morte : v < v_min + zone_morte -> v_min ; v > v_max - zone_morte -> v_max
 *   hystérésis : la valeur retournée ne change que si |v - derniere| > hysteresis
 * Produit maximal : 3 300 x 10 000 = 33 x 10^6, sans risque sur 32 bits.     */
int32_t acq_valeur(acq_t *a)
{
    int32_t v = ((int32_t)acq_mv(a) * a->gain_num) / a->gain_den + a->decalage;

    if (a->zone_morte > 0) {
        if (v < a->v_min + a->zone_morte) {
            v = a->v_min;
        } else if (v > a->v_max - a->zone_morte) {
            v = a->v_max;
        }
    }

    if (a->hysteresis > 0 && a->initialisee
        && ecart_abs(v, a->derniere) <= a->hysteresis) {
        return a->derniere;                  /* bruit : valeur inchangée      */
    }

    a->derniere = v;
    a->initialisee = 1u;
    return v;
}
