/* ---------------------------------------------------------------------------
 * vitesse.s — conversion des fronts d'encodeur en vitesse, virgule fixe
 *             (CEG 3536, laboratoire 3, E3)
 *
 * Routine exportée (AAPCS) : enc_fronts_vers_rpm_q16 (prototype dans lab3.h)
 *
 * Fenêtre de FENETRE_VITESSE_MS = 250 ms ; 748 fronts par tour de l'arbre de
 * sortie (2 fronts x 11 impulsions x 34). tr/min = fronts x 4 x 60 / 748
 * = fronts x 240 / 748.
 * Format Q16.16 : résultat = tr/min x 65536 = fronts x (240 x 65536 / 748).
 *
 * Calculs (consignés dans JOURNAL.md) :
 *   240 x 65536 / 748 = 15 728 640 / 748 = 21 027,594...  ->  k = 21 028
 *   erreur relative de k = (21028 - 21027,594) / 21027,594 = +0,0019 %
 *     (< 0,05 % exigé ; erreur de quantification du résultat <= 1/65536 tr/min
 *      en plus, négligeable)
 *   fronts maximal sans débordement 32 bits : floor((2^32 - 1) / 21028)
 *     = 204 249 (>> 65 535 exigé ; ~1 090 fronts à pleine vitesse)
 *   Cas de l'essai T3 (résultat Q16.16 -> tr/min) :
 *     0      -> 0            -> 0,00
 *     1      -> 21 028       -> 0,32
 *     748    -> 15 728 944   -> 240,00  (240,0046 ; réel 240,00)
 *     1 870  -> 39 322 360   -> 600,01  (600,0116 ; réel 600,00)
 *     65 535 -> 1 378 069 980 -> 21 027,68 (réel 21 027,27)
 *   (vérifié par émulation du code machine : erreur +0,0019 % sur tous les cas)
 *
 * Choix de réalisation : UMULL donne le produit sur 64 bits ; si la partie
 * haute est non nulle (fronts > 204 249, impossible en fonctionnement
 * normal), le résultat sature à 0xFFFFFFFF au lieu de s'enrouler. Routine
 * feuille : R0-R3 seulement, aucune pile, retour par BX LR.
 * Aucun registre périphérique n'est utilisé : les fichiers registres*.inc
 * ne sont pas nécessaires.
 * ------------------------------------------------------------------------- */

    .syntax unified
    .cpu    cortex-m33
    .thumb

    .equ RPM_Q16_K, 21028        /* identique à RPM_Q16_K de lab3.h */

    .text
    .align  2

/* uint32_t enc_fronts_vers_rpm_q16(uint32_t fronts)
 * r0 = fronts comptés dans la fenêtre ; retour r0 = tr/min en Q16.16.     */
    .global enc_fronts_vers_rpm_q16
    .type   enc_fronts_vers_rpm_q16, %function
enc_fronts_vers_rpm_q16:
    movw    r1, #RPM_Q16_K       /* r1 = k (16 bits : MOVW, pas de littéral) */
    umull   r0, r2, r0, r1       /* r2:r0 = fronts x k (64 bits)            */
    cmp     r2, #0               /* partie haute non nulle -> débordement   */
    it      ne
    movne   r0, #0xFFFFFFFF      /* saturation (MVN #0)                     */
    bx      lr                   /* r0 = résultat Q16.16                    */
    .size   enc_fronts_vers_rpm_q16, .-enc_fronts_vers_rpm_q16
