/* ---------------------------------------------------------------------------
 * telem.c — télémétrie LPUART1 au niveau des registres (CMSIS, sans HAL)
 *           (CEG 3536, laboratoire 3, E10)
 *
 * LPUART1 : TX = PG7, RX = PG8 (AF8), 115 200 bauds, 8N1, vers le port COM
 * virtuel du ST-LINK (guide, p. 54-55). Le port G (broches 2 à 15) est alimenté
 * par VDDIO2 : PWR_CR2.IOSV doit être mis à 1 (RM0438, section PWR).
 * Horloge noyau = PCLK1 = 4 MHz (RCC_CCIPR1.LPUART1SEL = 00) :
 *   BRR = 256 x fck / bauds (vérifier fck >= 3 x bauds).
 * FIFO activée (CR1.FIFOEN, 8 octets) : telem_step remplit la FIFO tant que
 * ISR.TXFNF est à 1, sans jamais attendre.
 *
 * Fourni : horloges, IOSV, broches, file logicielle (telem_put), formatage
 * entier, en-tête. Complété : BRR et CR1 (fin de telem_init), telem_step,
 * telem_rx, telem_trame.
 * Débit : une trame d'environ 45 à 60 caractères toutes les 200 ms, soit
 * ~ 2,5 % de la capacité de la liaison (11,5 ko/s). telem_step écrit au plus
 * 8 octets par tick (FIFO matérielle) : une trame part en ~ 6 à 8 ms, l'en-tête
 * (~ 105 caractères) en ~ 14 ms ; la file logicielle de 512 octets absorbe
 * aussi les réponses aux commandes série.
 * ------------------------------------------------------------------------- */
#include "stm32l552xx.h"
#include "telem.h"

#define TX_TAILLE 512u
static char     tx_file[TX_TAILLE];
static uint32_t tx_tete, tx_queue, tx_nombre, pertes;

void telem_init(uint32_t bauds)
{
    RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN;
    (void)RCC->APB1ENR1;
    PWR->CR2 |= PWR_CR2_IOSV;                         /* alimentation du port G */
    RCC->AHB2ENR |= RCC_AHB2ENR_GPIOGEN;
    RCC->APB1ENR2 |= RCC_APB1ENR2_LPUART1EN;
    RCC->CCIPR1 &= ~RCC_CCIPR1_LPUART1SEL;            /* 00 = PCLK1             */
    (void)RCC->APB1ENR2;

    /* PG7 (TX) : AFRL champ 7 = 8 ; PG8 (RX) : AFRH champ 0 = 8 ; MODER = 10 */
    GPIOG->AFR[0] = (GPIOG->AFR[0] & ~GPIO_AFRL_AFSEL7) | (8u << GPIO_AFRL_AFSEL7_Pos);
    GPIOG->AFR[1] = (GPIOG->AFR[1] & ~GPIO_AFRH_AFSEL8) | (8u << GPIO_AFRH_AFSEL8_Pos);
    GPIOG->MODER = (GPIOG->MODER & ~(GPIO_MODER_MODE7 | GPIO_MODER_MODE8))
                 | GPIO_MODER_MODE7_1 | GPIO_MODER_MODE8_1;
    GPIOG->OSPEEDR |= GPIO_OSPEEDR_OSPEED7_0;
    GPIOG->PUPDR = (GPIOG->PUPDR & ~GPIO_PUPDR_PUPD8) | GPIO_PUPDR_PUPD8_0; /* RX tiré à 1 */

    /* BRR = 256 x fck / bauds, arrondi : (1 024 000 000 + 57 600) / 115 200
     * = 8 889 (0x22B9) ; bauds réels = 256 x 4 MHz / 8 889 = 115 198 (-0,002 %).
     * fck = 4 MHz >= 3 x 115 200 = 345 600 : condition du LPUART respectée.
     * 256 x fck tient sur 32 bits pour fck <= 16 MHz.                        */
    LPUART1->CR1 = 0u;                                /* UE = 0 pour configurer */
    LPUART1->BRR = (256u * HORLOGE_HZ_C + bauds / 2u) / bauds;
    LPUART1->CR2 = 0u;                                /* 1 bit d'arrêt          */
    LPUART1->CR3 = 0u;                                /* sans contrôle de flux  */
    LPUART1->CR1 = USART_CR1_FIFOEN | USART_CR1_TE | USART_CR1_RE;  /* 8N1      */
    LPUART1->CR1 |= USART_CR1_UE;

    tx_tete = tx_queue = tx_nombre = pertes = 0u;
}

bool telem_put(const char *s)
{
    while (*s) {
        if (tx_nombre >= TX_TAILLE) {
            pertes++;
            return false;
        }
        tx_file[tx_queue] = *s++;
        tx_queue = (tx_queue + 1u) % TX_TAILLE;
        tx_nombre++;
    }
    return true;
}

/* Vide la file logicielle dans la FIFO matérielle tant qu'elle a de la place
 * (ISR.TXE_TXFNF = 1). Jamais d'attente active : si la FIFO est pleine, on
 * reprend au tick suivant. Une interruption (E-Stop) entre deux écritures de
 * TDR ne fait que retarder l'octet suivant : aucune trame n'est corrompue. */
void telem_step(void)
{
    while (tx_nombre > 0u && (LPUART1->ISR & USART_ISR_TXE_TXFNF)) {
        LPUART1->TDR = (uint8_t)tx_file[tx_tete];
        tx_tete = (tx_tete + 1u) % TX_TAILLE;
        tx_nombre--;
    }
}

/* Réception d'une commande d'un caractère, sans attente. */
int telem_rx(void)
{
    uint32_t isr = LPUART1->ISR;
    if (isr & USART_ISR_ORE) {
        LPUART1->ICR = USART_ICR_ORECF;               /* débordement effacé     */
    }
    if (isr & USART_ISR_RXNE_RXFNE) {
        return (int)(LPUART1->RDR & 0xFFu);
    }
    return -1;
}

uint32_t telem_pertes(void) { return pertes; }

/* ---- formatage entier [FOURNI] ---------------------------------------- */
char *telem_fmt_u32(char *p, uint32_t v)
{
    char tmp[11];
    int n = 0;
    do { tmp[n++] = (char)('0' + v % 10u); v /= 10u; } while (v);
    while (n) *p++ = tmp[--n];
    *p = '\0';
    return p;
}

char *telem_fmt_i32(char *p, int32_t v)
{
    uint32_t u = (uint32_t)v;
    if (v < 0) { *p++ = '-'; u = 0u - u; }        /* correct aussi pour INT32_MIN */
    return telem_fmt_u32(p, u);
}

/* ---- trames ------------------------------------------------------------ */
void telem_entete(void)
{
    telem_put("H,ticks_ms,etat,sens,consigne_pct,pwm_pct,temp_c_x10,vitesse_rpm_x100,nb_evenements,evq_debordements\r\n");
}

/* Ligne T,<ticks_ms>,<etat>,<sens>,<consigne_pct>,<pwm_pct>,<temp_c_x10>,
 * <vitesse_rpm_x100>,<nb_evenements>,<debordements>\r\n
 * Taille maximale : 2 + 9 champs x (11 + 1) + 2 = 112 caractères < 128.
 * La trame est construite entièrement avant telem_put : si la file
 * logicielle n'a pas la place pour toute la ligne, elle est refusée en bloc
 * (comptée dans pertes) plutôt que tronquée (E12 : aucune trame tronquée). */
static char *champ_u32(char *p, uint32_t v)
{
    *p++ = ',';
    return telem_fmt_u32(p, v);
}

void telem_trame(const etat_vehicule_t *v, int32_t temp_c_x10,
                 uint32_t nb_evenements, uint32_t debordements)
{
    char ligne[128];
    char *p = ligne;
    /* Q16.16 -> centièmes de tr/min, arrondi : (q16 x 100 + 2^15) >> 16 */
    uint32_t vitesse_x100 = (uint32_t)(((uint64_t)v->vitesse_rpm_q16 * 100u + 32768u) >> 16);
    uint32_t longueur;

    *p++ = 'T';
    p = champ_u32(p, ticks_ms);
    p = champ_u32(p, v->etat);
    p = champ_u32(p, v->sens);
    p = champ_u32(p, v->consigne_pct);
    p = champ_u32(p, v->pwm_pct);
    *p++ = ',';
    p = telem_fmt_i32(p, temp_c_x10);
    p = champ_u32(p, vitesse_x100);
    p = champ_u32(p, nb_evenements);
    p = champ_u32(p, debordements);
    *p++ = '\r';
    *p++ = '\n';
    *p = '\0';

    longueur = (uint32_t)(p - ligne);
    if (TX_TAILLE - tx_nombre < longueur) {
        pertes += longueur;                           /* refus en bloc          */
        return;
    }
    (void)telem_put(ligne);
}
