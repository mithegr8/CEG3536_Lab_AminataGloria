/* ---------------------------------------------------------------------------
 * adc_dma.c — pilote ADC1 + DMA1 au niveau des registres (CMSIS, sans HAL)
 *             (CEG 3536, laboratoire 3, E4)
 *
 * Séquence (RM0438, sections ADC, DMA, DMAMUX ; énoncé 4.8) :
 *   1. horloges ADC (AHB2), DMA1 et DMAMUX1 (AHB1), GPIOC ; PC0, PC1 analogiques
 *   2. horloge de l'ADC : ADC12_COMMON->CCR, CKMODE = 01 (HCLK/1, synchrone)
 *   3. sortie du mode basse consommation (DEEPPWD = 0), régulateur (ADVREGEN,
 *      attendre > 20 µs), étalonnage (ADCAL puis attendre sa retombée, ADEN = 0
 *      pendant l'étalonnage), activation (ISR = ADRDY (w1c), ADEN, attendre
 *      ISR.ADRDY)
 *   4. CFGR : RES = 00 (12 bits), CONT, DMAEN, DMACFG (circulaire), OVRMOD ;
 *      SMPR1 : SMP1 = SMP2 = 111 (640,5 cycles) ; SQR1 : L = 1 (2 conversions),
 *      SQ1 = 1 (IN1 = PC0), SQ2 = 2 (IN2 = PC1)
 *   5. DMAMUX1_Channel0->CCR = 5 (requête ADC1) ; DMA1_Channel1 : CPAR =
 *      &ADC1->DR, CM0AR = tampon, CNDTR = ADC_N_VOIES x n_par_voie,
 *      CCR = MINC | PSIZE_0 | MSIZE_0 | CIRC (DIR = 0), puis EN
 *   6. ADSTART
 * Débit par voie = 4 MHz / (2 x (640,5 + 12,5)) ~ 3 063 Hz ; un tour du
 * tampon de 64 échantillons par voie dure ~ 20,9 ms (16 : ~ 5,2 ms) ;
 * vérifié par adc_dma_tours (T4 : ~ 47,9 tours par seconde avec 64).
 * Vérification au débogueur : ADC1->CR = 0x10000005 (ADVREGEN, ADSTART,
 * ADEN), ISR.ADRDY = 1, DMA1_Channel1->CNDTR qui décroît et se recharge,
 * tampon qui évolue quand on bouge le potentiomètre.
 *
 * Les attentes actives de ce fichier ne servent qu'à l'initialisation (avant
 * la boucle principale) et sont bornées par le matériel (quelques µs).
 * ------------------------------------------------------------------------- */
#include "stm32l552xx.h"
#include "lab3.h"
#include "adc_dma.h"

#define DMAMUX_REQ_ADC1   5u      /* RM0438, tableau des requêtes DMAMUX1    */

static uint32_t tours;

/* Attente courte indépendante de SysTick : ~ 6 cycles par itération,
 * 4 MHz -> 100 itérations ~ 150 µs (> 20 µs exigées pour le régulateur). */
static void attente_courte(uint32_t n)
{
    for (volatile uint32_t i = 0u; i < n; i++) {
    }
}

void adc_dma_init(volatile uint16_t *tampon, uint32_t n_par_voie)
{
    /* 1. horloges et broches analogiques */
    RCC->AHB2ENR |= RCC_AHB2ENR_GPIOCEN | RCC_AHB2ENR_ADCEN;
    RCC->AHB1ENR |= RCC_AHB1ENR_DMA1EN | RCC_AHB1ENR_DMAMUX1EN;
    (void)RCC->AHB1ENR;
    GPIOC->MODER |= GPIO_MODER_MODE0 | GPIO_MODER_MODE1;      /* 11 = analogique */
    GPIOC->PUPDR &= ~(GPIO_PUPDR_PUPD0 | GPIO_PUPDR_PUPD1);

    /* 2. horloge ADC : CKMODE = 01 -> HCLK / 1 (synchrone, 4 MHz) */
    ADC12_COMMON->CCR = (ADC12_COMMON->CCR & ~ADC_CCR_CKMODE) | ADC_CCR_CKMODE_0;

    /* 3a. sortie du mode deep-power-down, régulateur */
    ADC1->CR &= ~ADC_CR_DEEPPWD;
    ADC1->CR |= ADC_CR_ADVREGEN;
    attente_courte(100u);                                     /* tADCVREG_STUP */

    /* 3b. étalonnage en mode asymétrique (ADEN = 0, ADCALDIF = 0) */
    ADC1->CR &= ~(ADC_CR_ADEN | ADC_CR_ADCALDIF);
    ADC1->CR |= ADC_CR_ADCAL;
    while (ADC1->CR & ADC_CR_ADCAL) {
    }
    attente_courte(4u);              /* >= 4 cycles d'horloge ADC avant ADEN */

    /* 3c. activation */
    ADC1->ISR = ADC_ISR_ADRDY;                                /* w1c          */
    ADC1->CR |= ADC_CR_ADEN;
    while ((ADC1->ISR & ADC_ISR_ADRDY) == 0u) {
    }
    ADC1->ISR = ADC_ISR_ADRDY;

    /* 4. conversion : 12 bits, alignée à droite, continue, DMA circulaire,
     *    écrasement en cas de débordement (OVRMOD = 1), déclenchement logiciel */
    ADC1->CFGR = ADC_CFGR_CONT | ADC_CFGR_DMAEN | ADC_CFGR_DMACFG | ADC_CFGR_OVRMOD;
    ADC1->SMPR1 = (ADC1->SMPR1 & ~(ADC_SMPR1_SMP1 | ADC_SMPR1_SMP2))
                | ADC_SMPR1_SMP1 | ADC_SMPR1_SMP2;            /* 111 = 640,5 cycles */
    ADC1->SQR1 = ((ADC_N_VOIES - 1u) << ADC_SQR1_L_Pos)       /* L = 1 : 2 conv.  */
               | (1u << ADC_SQR1_SQ1_Pos)                     /* IN1 = PC0        */
               | (2u << ADC_SQR1_SQ2_Pos);                    /* IN2 = PC1        */

    /* 5. DMAMUX et DMA (canal désactivé pendant la configuration) */
    DMA1_Channel1->CCR = 0u;
    DMAMUX1_Channel0->CCR = DMAMUX_REQ_ADC1;
    DMA1_Channel1->CPAR  = (uint32_t)&ADC1->DR;
    DMA1_Channel1->CM0AR = (uint32_t)tampon;
    DMA1_Channel1->CNDTR = ADC_N_VOIES * n_par_voie;
    DMA1->IFCR = DMA_IFCR_CGIF1;                              /* drapeaux à 0   */
    DMA1_Channel1->CCR = DMA_CCR_MINC | DMA_CCR_PSIZE_0 | DMA_CCR_MSIZE_0
                       | DMA_CCR_CIRC;                        /* DIR = 0        */
    DMA1_Channel1->CCR |= DMA_CCR_EN;
    tours = 0u;

    /* 6. départ des conversions */
    ADC1->CR |= ADC_CR_ADSTART;
}

void adc_dma_step(void)
{
    if (DMA1->ISR & DMA_ISR_TCIF1) {                          /* tour complet  */
        DMA1->IFCR = DMA_IFCR_CTCIF1;
        tours++;
    }
}

uint32_t adc_dma_tours(void)
{
    return tours;
}
