################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
../Src/buttons.s \
../Src/buzzer.s \
../Src/encoder.s \
../Src/estop.s \
../Src/gpio.s \
../Src/motor.s \
../Src/startup_stm32l552xx.s \
../Src/systick.s \
../Src/vitesse.s 

C_SRCS += \
../Src/acq.c \
../Src/adc_dma.c \
../Src/bench_l3a.c \
../Src/evq.c \
../Src/evq_test.c \
../Src/fsm.c \
../Src/l3a_c.c \
../Src/main.c \
../Src/syscalls.c \
../Src/sysmem.c \
../Src/telem.c 

OBJS += \
./Src/acq.o \
./Src/adc_dma.o \
./Src/bench_l3a.o \
./Src/buttons.o \
./Src/buzzer.o \
./Src/encoder.o \
./Src/estop.o \
./Src/evq.o \
./Src/evq_test.o \
./Src/fsm.o \
./Src/gpio.o \
./Src/l3a_c.o \
./Src/main.o \
./Src/motor.o \
./Src/startup_stm32l552xx.o \
./Src/syscalls.o \
./Src/sysmem.o \
./Src/systick.o \
./Src/telem.o \
./Src/vitesse.o 

S_DEPS += \
./Src/buttons.d \
./Src/buzzer.d \
./Src/encoder.d \
./Src/estop.d \
./Src/gpio.d \
./Src/motor.d \
./Src/startup_stm32l552xx.d \
./Src/systick.d \
./Src/vitesse.d 

C_DEPS += \
./Src/acq.d \
./Src/adc_dma.d \
./Src/bench_l3a.d \
./Src/evq.d \
./Src/evq_test.d \
./Src/fsm.d \
./Src/l3a_c.d \
./Src/main.d \
./Src/syscalls.d \
./Src/sysmem.d \
./Src/telem.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m33 -std=gnu11 -DDEBUG -DSTM32L552xx '-D/Drivers/CMSIS/Device/ST/STM32L5xx/Include' -DSTM32 -DSTM32L5 -DSTM32L552ZETxQ -c -I../Inc -I/Drivers/CMSIS/Include -I/Drivers/CMSIS/Device/ST/STM32L5xx/Include -Os -ffunction-sections -fdata-sections -Wall -Wextra -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Src/%.o: ../Src/%.s Src/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m33 -c -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/acq.cyclo ./Src/acq.d ./Src/acq.o ./Src/acq.su ./Src/adc_dma.cyclo ./Src/adc_dma.d ./Src/adc_dma.o ./Src/adc_dma.su ./Src/bench_l3a.cyclo ./Src/bench_l3a.d ./Src/bench_l3a.o ./Src/bench_l3a.su ./Src/buttons.d ./Src/buttons.o ./Src/buzzer.d ./Src/buzzer.o ./Src/encoder.d ./Src/encoder.o ./Src/estop.d ./Src/estop.o ./Src/evq.cyclo ./Src/evq.d ./Src/evq.o ./Src/evq.su ./Src/evq_test.cyclo ./Src/evq_test.d ./Src/evq_test.o ./Src/evq_test.su ./Src/fsm.cyclo ./Src/fsm.d ./Src/fsm.o ./Src/fsm.su ./Src/gpio.d ./Src/gpio.o ./Src/l3a_c.cyclo ./Src/l3a_c.d ./Src/l3a_c.o ./Src/l3a_c.su ./Src/main.cyclo ./Src/main.d ./Src/main.o ./Src/main.su ./Src/motor.d ./Src/motor.o ./Src/startup_stm32l552xx.d ./Src/startup_stm32l552xx.o ./Src/syscalls.cyclo ./Src/syscalls.d ./Src/syscalls.o ./Src/syscalls.su ./Src/sysmem.cyclo ./Src/sysmem.d ./Src/sysmem.o ./Src/sysmem.su ./Src/systick.d ./Src/systick.o ./Src/telem.cyclo ./Src/telem.d ./Src/telem.o ./Src/telem.su ./Src/vitesse.d ./Src/vitesse.o

.PHONY: clean-Src

