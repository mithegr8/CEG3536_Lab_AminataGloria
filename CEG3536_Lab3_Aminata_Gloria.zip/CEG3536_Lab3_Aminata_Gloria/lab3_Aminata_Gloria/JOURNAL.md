# JOURNAL.md — Journal d'équipe, CEG 3536, laboratoire 3 (automne 2026)

Équipe : Aminata Aliou et Gloria Tiendrébéogo — Section : A01 — Dépôt Git : https://github.com/mithegr8/CEG3536_Lab_AminataGloria

## Jalon J2 — module d'événements testé sur hôte

| Plateforme | Compilateur et version | Commande | Résultat (cas réussis / échecs) |
|---|---|---|---|
| Windows | non testé | non testé | non testé |
| Linux | GCC 14.2.0 | `gcc -std=gnu11 -Wall -Wextra -O0 -g -IInc` (le Makefile de `hote/` pointe vers `../Core/`, absent de notre projet) | 13 réussis / 0 échec, aucun avertissement |
| STM32 (cible) | arm-none-eabi-gcc 14.3.1 (STM32CubeIDE 2.2.0) | commande série `q` | `Q,echecs=0` (0 échec), le 13 novembre 2026 |

Cas ajoutés par l'équipe (au-delà des 9 fournis) :

| Description | Résultat |
|---|---|
| Saturation par 40 événements d'un coup | réussi |
| Enroulements multiples de l'index | réussi |
| Remise à zéro des compteurs | réussi |

Différences observées entre hôtes : sur Linux 64 bits, `sizeof(evq_event_t)` = 12 octets, `int` = 32 bits et `long` = 64 bits. Sur la cible, `long` fait 32 bits. Le module n'utilise que des types de taille fixe (`uint32_t`), donc ce changement ne l'affecte pas.

## Calculs préalables

| Grandeur | Formule | Valeur | Vérifiée par |
|---|---|---|---|
| `RPM_Q16_K` | round(240 × 65 536 / 748) | 21 028 (exact : 21 027,594) | T3 |
| Erreur relative de la constante | (k − 240 × 65 536 / 748) / (240 × 65 536 / 748) | +0,0019 % | T3 |
| fronts maximal sans débordement | 2³² / k | 204 249 | T3 |
| `LPUART1_BRR` | 256 × 4 000 000 / 115 200 | 8 889 (lu : 0x22B9) | T9 |
| Débit ADC par voie | 4 MHz / (2 × (640,5 + 12,5)) | 3 063 Hz (mesuré : 3 060 Hz) | T4 |
| Durée d'un tour du tampon DMA | 64 / débit par voie | 20,9 ms (64 échantillons par voie depuis la version 2) | T4 |
| Résolution de la température | 3 300 mV / 4 095 / 10,9 mV/°C | 0,074 °C par pas | T6 |

## Étalonnage de la température (E6)

| Mesure | Résultat | `temp_mv` lu | `TEMP_MV_REF` / `TEMP_C10_REF` retenus | Position de S2 |
|---|---|---|---|---|
| Ambiante | 24,8 °C affiché, aucun thermomètre de référence | 1 832 à 1 833 mV | 1 831 mV / 250 (point nominal de 25,0 °C) | gauche (interne) |
| Capteur pincé avec une main froide | baisse à 24,1 °C en 7 s | | 1 831 mV / 250 | gauche (interne) |

Analyse interne / externe : avec le conditionnement interne, la plage utile de 15 à 40 °C ne couvre qu'environ 340 pas de l'ADC (0,074 °C par pas). La résolution suffit ; l'erreur principale vient de l'étalonnage, fait avec le point nominal du capteur faute de thermomètre. Un conditionnement externe avec gain élargirait la plage de tension utilisée et réduirait l'effet du bruit, mais il n'a pas été monté.

## Journal des séances

### Séance 1 — 6 novembre 2026
- Objectifs : migrer le projet du laboratoire 2 vers un programme principal en C.
- Fait : création d'un nouveau projet STM32 (STM32L552ZETxQ) et intégration des fichiers C et assembleur.
- Décisions : routine L3-A changée pour `motor_set_pwm`, au lieu de `button_pressed` prévue au jalon J1, car son résultat se vérifie directement par la valeur renvoyée et par le registre CCR1.
- Difficultés et solutions : le projet importé n'était pas reconnu comme projet C par STM32CubeIDE (« Unable to launch ») ; nous avons recréé un projet STM32 et y avons copié les sources.

### Séance 2 — 13 novembre 2026
- Objectifs : faire fonctionner le programme sur la carte et réaliser les essais T1 à T10.
- Fait : essais T1 à T9 réalisés et capturés ; démonstration devant l'assistant.
- Décisions : ajout du fichier de démarrage de STMicroelectronics.
- Difficultés et solutions : après le retrait de `main.s`, le projet n'avait plus de fichier de démarrage (`Reset_Handler` introuvable, programme réduit à 96 octets) ; ajout de `startup_stm32l552xx.s`. Deux consoles ouvertes sur COM4 bloquaient le port ; une seule a été conservée.
- Mesures : température 24,8 °C au repos ; débit ADC 3 060 Hz par voie ; vitesse maximale 352,6 tr/min ; cadence de télémétrie 4,98 Hz.

## Composante L3-A : comparaison assembleur / C

Routine comparée : `motor_set_pwm`

| Cas | Entrée | Résultat assembleur | Effet de bord |
|---|---|---|---|
| 1 | 0 % | 0 (labo 2) | CCR1 = 0 |
| 2 | 25 % | 50 (labo 2) | CCR1 = 50 |
| 3 | 50 % | 100 (labo 2) | CCR1 = 100 |
| 4 | 100 % | 200 (labo 2) | CCR1 = 200 |

Le banc `bench_l3a` contient 8 cas (`BENCH_N_CAS = 8`), mais la commande `b` n'a pas été lancée sur la carte : les résultats de la version C et les cycles ne sont pas mesurés.

| Version | Taille (octets) | Registres utilisés | Observations (prologue, volatile) |
|---|---|---|---|
| Assembleur | 24 | r0 à r2 | aucun prologue, aucune pile ; `mul` puis `udiv` |
| C, -O0 | 64 | r0, r2, r3, r7, sp | sauvegarde r7, 20 octets de pile, pct recopié sur la pile ; division remplacée par `umull` avec 0x51EB851F ; écriture CCR1 conservée |
| C, -O2 | 20 | r0, r3 | aucun prologue ; (pct × 200) / 100 remplacé par `lsls r0, r0, #1` ; écriture CCR1 conservée |

## Composante L3-C : objet d'acquisition

- Version 1 : `versions/acq_v1.c`
- Version 2 et ce qui a changé : `Src/acq.c` ; zone morte de 3 %, hystérésis de 2 points, moyenne sur 64 échantillons pour la température ; seuls `acq.c` et l'initialisation dans `main.c` ont changé.
- Essai d'indépendance des deux instances : `test_acq` (12 cas réussis) ; potentiomètre à 50 % avant et après une modification du gain de la température.
- Comparaison avec la version impérative : faite sur la conception ; version impérative non jointe.
- Limites : 56 octets par instance (mesuré sur Linux 64 bits), conversion uniquement linéaire, lecture du tampon DMA sans protection (écart d'au plus 21 ms dans la moyenne).

## Composante L3-D : traces

| Élément | Preuve (fichier) |
|---|---|
| Désassemblage -O0 annoté | `Debug/lab3_Aminata_Gloria.list` (-O0), rapport section 5 |
| Désassemblage -O2 annoté | `Debug/lab3_Aminata_Gloria.list` (-O2), rapport section 6.3 |
| Trois instructions et leur encodage Thumb | rapport section 6.2, confirmé par le `.list` |
| Captures du débogueur (R0–R3, SP, variable volatile) | annexe T2 ; relecture de `tick_1ms` à chaque tour visible dans le `.list` -O2 |
| Transformation analysée | (pct × 200) / 100 devient un décalage d'un bit à -O2 ; cycles non mesurés |

## Tableau des essais (T1 à T10)

| Essai | Date | Résultat observé | Verdict | Preuve (fichier) |
|---|---|---|---|---|
| T1 Initialisation en C | 13 nov. 2026 | En-tête reçu, première trame à 200 ms, ARRÊT, PWM 0 | Conforme | annexe T1, ADC, DMA, LPUART |
| T2 Appel C → assembleur | 13 nov. 2026 | Paramètre dans R0, SP multiple de 8, LR valide, deux routines | Conforme | annexe T2 |
| T3 Virgule fixe | 13 nov. 2026 | 5 cas exacts lus dans R0 | Conforme | annexe T3 |
| T4 ADC et DMA | 13 nov. 2026 | Brut 0 / 2 214 / 4 095 ; débit 3 060 Hz par voie | Conforme | annexe T4 |
| T5 Consigne | 13 nov. 2026 | Suit 0 à 100 % dans les deux sens ; sans effet en ARRÊT | Conforme | annexe T5 |
| T6 Température | 13 nov. 2026 | 24,8 °C au repos ; 24,1 °C main froide ; pas de réchauffement | Non concluant | annexe T6 |
| T7 File d'événements | 13 nov. 2026 | 13/13 Linux ; 0 échec cible ; 8 débordements sur 40 injectés | Conforme sauf Windows | annexe T7 |
| T8 E-Stop | 13 nov. 2026 | Arrêt à 100 %, trames intactes, pas de reprise sans Touch En | Conforme | annexe T8 |
| T9 Télémétrie | 13 nov. 2026 | 4,98 Hz, aucune trame tronquée ; script non lancé | Partiel | annexes T1 et T5 |
| T10 Comparaison et traces | 17 nov. 2026 | Tailles et désassemblage -O0 / -O2 ; banc et cycles non mesurés | Partiel | fichiers `.list` |

## Déclaration des sources et de l'usage d'outils d'IA générative
- Sources : complément `CEG3536_Lab3_Complement.zip`, en-têtes CMSIS, fichier de démarrage `startup_stm32l552xx.s` de STMicroelectronics, rapport du laboratoire 2 de l'équipe, manuel Zhu (4e éd.), RM0438, DS12737, PM0264, guide de plateforme.
- Outils d'IA : Claude (Anthropic), utilisé pour le dépannage du projet dans STM32CubeIDE Aucun outil d'IA pendant la démonstration ni pendant les questions individuelles.