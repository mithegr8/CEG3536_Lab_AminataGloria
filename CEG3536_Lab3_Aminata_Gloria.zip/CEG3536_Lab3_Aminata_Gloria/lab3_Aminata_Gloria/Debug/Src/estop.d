Src/estop.o: ../Src/estop.s ../Src/registres.inc \
 ../Src/registres_lab2.inc
../Src/registres.inc:
../Src/registres_lab2.inc:
