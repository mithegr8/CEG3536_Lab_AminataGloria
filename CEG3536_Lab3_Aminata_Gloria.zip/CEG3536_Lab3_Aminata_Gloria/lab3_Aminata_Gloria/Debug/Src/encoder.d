Src/encoder.o: ../Src/encoder.s ../Src/registres.inc \
 ../Src/registres_lab2.inc
../Src/registres.inc:
../Src/registres_lab2.inc:
