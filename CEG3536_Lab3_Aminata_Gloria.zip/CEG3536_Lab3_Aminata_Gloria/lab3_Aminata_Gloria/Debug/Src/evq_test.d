Src/evq_test.o: ../Src/evq_test.c ../Inc/evq.h ../Inc/evq_test.h
../Inc/evq.h:
../Inc/evq_test.h:
