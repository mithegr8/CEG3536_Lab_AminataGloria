Src/fsm.o: ../Src/fsm.c ../Inc/fsm.h ../Inc/lab3.h ../Inc/lab2.h \
 ../Inc/lab1.h ../Inc/evq.h
../Inc/fsm.h:
../Inc/lab3.h:
../Inc/lab2.h:
../Inc/lab1.h:
../Inc/evq.h:
