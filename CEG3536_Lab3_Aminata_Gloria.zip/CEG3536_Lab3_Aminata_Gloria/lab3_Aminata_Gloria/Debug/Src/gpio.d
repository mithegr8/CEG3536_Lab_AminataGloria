Src/gpio.o: ../Src/gpio.s ../Src/registres.inc
../Src/registres.inc:
