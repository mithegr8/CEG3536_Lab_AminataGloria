Src/acq.o: ../Src/acq.c ../Inc/acq.h
../Inc/acq.h:
