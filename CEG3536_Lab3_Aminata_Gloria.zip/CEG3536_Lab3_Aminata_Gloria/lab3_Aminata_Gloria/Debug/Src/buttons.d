Src/buttons.o: ../Src/buttons.s ../Src/registres.inc
../Src/registres.inc:
