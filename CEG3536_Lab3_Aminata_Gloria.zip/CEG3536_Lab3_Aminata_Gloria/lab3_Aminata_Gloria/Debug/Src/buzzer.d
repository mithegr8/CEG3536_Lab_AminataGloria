Src/buzzer.o: ../Src/buzzer.s ../Src/registres.inc \
 ../Src/registres_lab2.inc
../Src/registres.inc:
../Src/registres_lab2.inc:
