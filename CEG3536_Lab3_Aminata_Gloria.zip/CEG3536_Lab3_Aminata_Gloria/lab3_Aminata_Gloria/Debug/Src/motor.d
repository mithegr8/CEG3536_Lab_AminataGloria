Src/motor.o: ../Src/motor.s ../Src/registres.inc \
 ../Src/registres_lab2.inc
../Src/registres.inc:
../Src/registres_lab2.inc:
