Src/systick.o: ../Src/systick.s ../Src/registres.inc \
 ../Src/registres_lab2.inc
../Src/registres.inc:
../Src/registres_lab2.inc:
