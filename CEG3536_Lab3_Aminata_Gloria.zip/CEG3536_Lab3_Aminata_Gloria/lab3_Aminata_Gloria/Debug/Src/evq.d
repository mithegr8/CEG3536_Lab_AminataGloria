Src/evq.o: ../Src/evq.c ../Inc/evq.h
../Inc/evq.h:
