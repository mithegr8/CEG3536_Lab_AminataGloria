Src/vitesse.o: ../Src/vitesse.s
