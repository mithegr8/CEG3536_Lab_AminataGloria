Src/main.o: ../Src/main.c \
 ../Drivers/CMSIS/Device/ST/STM32L5xx/Include/stm32l552xx.h \
 ../Drivers/CMSIS/Include/core_cm33.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv8.h \
 ../Drivers/CMSIS/Device/ST/STM32L5xx/Include/system_stm32l5xx.h \
 ../Inc/lab3.h ../Inc/lab2.h ../Inc/lab1.h ../Inc/evq.h ../Inc/evq_test.h \
 ../Inc/acq.h ../Inc/adc_dma.h ../Inc/telem.h ../Inc/lab3.h ../Inc/fsm.h \
 ../Inc/evq.h ../Inc/bench_l3a.h
../Drivers/CMSIS/Device/ST/STM32L5xx/Include/stm32l552xx.h:
../Drivers/CMSIS/Include/core_cm33.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv8.h:
../Drivers/CMSIS/Device/ST/STM32L5xx/Include/system_stm32l5xx.h:
../Inc/lab3.h:
../Inc/lab2.h:
../Inc/lab1.h:
../Inc/evq.h:
../Inc/evq_test.h:
../Inc/acq.h:
../Inc/adc_dma.h:
../Inc/telem.h:
../Inc/lab3.h:
../Inc/fsm.h:
../Inc/evq.h:
../Inc/bench_l3a.h:
