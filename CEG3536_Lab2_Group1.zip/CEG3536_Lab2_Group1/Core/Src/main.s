/* ---------------------------------------------------------------------------
 * main.s — point d'entrée et boucle principale (CEG 3536, laboratoire 2)
 *
 * Initialisations, puis boucle cadencée par SysTick : fsm_step est exécutée
 * une fois par tick de 1 ms (tick_1ms positionné par SysTick_Handler).
 * delay_ms n'est plus appelée dans la boucle (E10).
 * ------------------------------------------------------------------------- */
#include "registres.inc"
#include "registres_lab2.inc"

    .syntax unified
    .cpu    cortex-m33
    .thumb

    .text
    .align  2

/* void SystemInit(void) : horloge MSI 4 MHz laissée telle quelle. */
    .global SystemInit
    .type   SystemInit, %function
SystemInit:
    bx      lr
    .size   SystemInit, .-SystemInit

/* int main(void) — ne retourne jamais.
 * Les sorties sont mises en état sûr (moteur arrêté, buzzer muet, DEL
 * rouge) AVANT l'activation de SysTick (E1).                               */
    .global main
    .type   main, %function
main:
    bl      gpio_init               /* DEL en sortie, boutons en entrée      */
    bl      buzzer_init             /* PA0 en sortie, silence                */
    bl      motor_init              /* TIM1 PWM 20 kHz à 0 %, STB = 0        */
    bl      encoder_init            /* EXTI0 sur PB0, priorité 1             */
    bl      estop_init              /* EXTI2 sur PB2, priorité 0             */
    bl      fsm_init                /* ARRÊT, DEL rouge seule (E1)           */
    ldr     r0, =SYSTICK_PERIODE_US
    bl      systick_init            /* 1 ms, priorité 2                      */

boucle_principale:
    ldr     r0, =tick_1ms
    ldr     r1, [r0]
    cmp     r1, #0
    beq     boucle_principale       /* attente du prochain tick              */
    movs    r1, #0
    str     r1, [r0]                /* tick consommé                         */
    bl      fsm_step
    b       boucle_principale
    .size   main, .-main
    .ltorg
