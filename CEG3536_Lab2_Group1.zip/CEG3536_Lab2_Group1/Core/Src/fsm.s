/* ---------------------------------------------------------------------------
 * fsm.s — machine à états du véhicule (CEG 3536, laboratoire 2)
 *
 * Routines exportées : fsm_init, fsm_step
 * Variables (.bss)   : etat, touch_enabled (inutilisée, gardée pour lab1.h),
 *                      compteur_transitions, prochain_sens, consigne_pct,
 *                      pwm_pct, rampe_compteur, fenetre_compteur,
 *                      clignote_compteur, clignote_phase
 *
 * fsm_step est appelée UNE fois par tick de 1 ms (E10).
 * Un seul point de mise à jour des sorties : fsm_maj_sorties (B4) :
 * rampe -> moteur, DEL, buzzer. Les changements d'état passent par
 * fsm_entree_etat (direction + bips).
 * ------------------------------------------------------------------------- */
#include "registres.inc"
#include "registres_lab2.inc"

    .syntax unified
    .cpu    cortex-m33
    .thumb

    .bss
    .align  2
    .global etat
etat:                   .space  4   /* état courant (ETAT_x)                     */
    .global touch_enabled
touch_enabled:          .space  4   /* inutilisée au lab. 2, reste à 0           */
    .global compteur_transitions
compteur_transitions:   .space  4   /* nombre de transitions                     */
    .global prochain_sens
prochain_sens:          .space  4   /* 0 : prochain départ AVANT, 1 : ARRIÈRE    */
    .global consigne_pct
consigne_pct:           .space  4   /* 25, 50, 75 ou 100 %                       */
    .global pwm_pct
pwm_pct:                .space  4   /* rapport cyclique appliqué (rampe)         */
rampe_compteur:         .space  4   /* ms écoulées depuis le dernier pas de rampe */
fenetre_compteur:       .space  4   /* ms écoulées dans la fenêtre de vitesse    */
clignote_compteur:      .space  4   /* ms écoulées dans la demi-période          */
clignote_phase:         .space  4   /* 0 rouge éteinte, 1 rouge allumée          */

/* ---- Tables indexées par l'état ----------------------------------------- */
    .section .rodata
etat_vers_del:
    .byte   LED_ROUGE, LED_VERTE, LED_BLEUE, LED_ROUGE
etat_vers_dir:
    .byte   MOTOR_ARRET, MOTOR_AVANT, MOTOR_ARRIERE, MOTOR_ARRET
etat_nb_bips:
    .byte   1, 1, 2, 1              /* bip court ; court ; double ; (urgence : continu) */

    .text
    .align  2

/* void fsm_init(void) : ARRÊT, tout à zéro, consigne 50 %, DEL rouge (E1).
 * Aucun bip à la mise sous tension.                                         */
    .global fsm_init
    .type   fsm_init, %function
fsm_init:
    push    {r4, lr}
    movs    r1, #0
    ldr     r0, =etat
    movs    r2, #ETAT_ARRET
    str     r2, [r0]
    ldr     r0, =touch_enabled
    str     r1, [r0]
    ldr     r0, =compteur_transitions
    str     r1, [r0]
    ldr     r0, =prochain_sens
    str     r1, [r0]
    ldr     r0, =pwm_pct
    str     r1, [r0]
    ldr     r0, =rampe_compteur
    str     r1, [r0]
    ldr     r0, =fenetre_compteur
    str     r1, [r0]
    ldr     r0, =clignote_compteur
    str     r1, [r0]
    ldr     r0, =clignote_phase
    str     r1, [r0]
    ldr     r0, =consigne_pct
    movs    r2, #CONSIGNE_INITIALE
    str     r2, [r0]
    bl      fsm_maj_sorties
    pop     {r4, pc}
    .size   fsm_init, .-fsm_init

/* void fsm_step(void) : un pas par tick de 1 ms.
 *   0. fenêtre de vitesse (500 ms) : encoder_read(&sens_mesure)
 *   A. estop_flag -> ARRÊT_URGENCE (E7/E8)
 *   B. en urgence : User ignoré ; Touch En + E-Stop relâché -> ARRÊT (E8)
 *   C. sinon : User -> transition (E3) ; Touch En -> consigne suivante (E4)
 *   D. fsm_maj_sorties (rampe, DEL, buzzer)
 * Registres : r4-r6 sauvegardés ; LR sauvegardé (appels) ; pile alignée.    */
    .global fsm_step
    .type   fsm_step, %function
fsm_step:
    push    {r4, r5, r6, lr}

    /* 0. fenêtre de mesure de vitesse (E6) */
    ldr     r5, =fenetre_compteur
    ldr     r0, [r5]
    adds    r0, r0, #1
    cmp     r0, #FENETRE_VITESSE_MS
    blo     fsm_step_fenetre_stocke
    movs    r0, #0
    str     r0, [r5]
    ldr     r0, =sens_mesure
    bl      encoder_read            /* met aussi à jour vitesse_fronts       */
    b       fsm_step_evenements
fsm_step_fenetre_stocke:
    str     r0, [r5]

fsm_step_evenements:
    /* A. E-Stop reçu ? */
    ldr     r5, =estop_flag
    ldr     r0, [r5]
    cmp     r0, #1
    beq     fsm_step_estop
    /* B. déjà en urgence ? */
    ldr     r5, =etat
    ldr     r0, [r5]
    cmp     r0, #ETAT_ARRET_URGENCE
    beq     fsm_step_urgence

    /* C1. User : défilement rouge -> verte -> rouge -> bleue -> rouge */
    movs    r0, #BTN_USER
    bl      button_pressed
    cmp     r0, #0
    beq     fsm_step_touch
    ldr     r5, =etat
    ldr     r0, [r5]
    cmp     r0, #ETAT_ARRET
    bne     fsm_step_vers_arret
    ldr     r6, =prochain_sens
    ldr     r1, [r6]
    cmp     r1, #0
    bne     fsm_step_vers_arriere
    movs    r0, #ETAT_MARCHE_AVANT
    movs    r1, #1                  /* le prochain départ sera ARRIÈRE       */
    str     r1, [r6]
    b       fsm_step_transition
fsm_step_vers_arriere:
    movs    r0, #ETAT_MARCHE_ARRIERE
    movs    r1, #0                  /* le prochain départ sera AVANT         */
    str     r1, [r6]
    b       fsm_step_transition
fsm_step_vers_arret:
    movs    r0, #ETAT_ARRET
fsm_step_transition:
    bl      fsm_entree_etat

    /* C2. Touch En : consigne suivante (E4) */
fsm_step_touch:
    movs    r0, #BTN_TOUCH
    bl      button_pressed
    cmp     r0, #1
    bne     fsm_step_sorties
    ldr     r5, =consigne_pct
    ldr     r0, [r5]
    adds    r0, r0, #CONSIGNE_PAS
    cmp     r0, #CONSIGNE_MAX
    it      hi
    movhi   r0, #CONSIGNE_MIN       /* 100 -> 25                             */
    str     r0, [r5]
    movs    r0, #1
    bl      buzzer_bip              /* bip court                             */
    b       fsm_step_sorties

/* A. E-Stop consommé : l'ISR a déjà coupé la propulsion ; on garantit l'état */
fsm_step_estop:
    bl      motor_stop_now
    movs    r0, #0
    ldr     r5, =estop_flag
    str     r0, [r5]                /* drapeau consommé                      */
    ldr     r5, =pwm_pct
    str     r0, [r5]
    ldr     r5, =rampe_compteur
    str     r0, [r5]
    ldr     r5, =clignote_compteur
    str     r0, [r5]
    movs    r0, #1
    ldr     r5, =buzzer_continu
    str     r0, [r5]
    ldr     r5, =clignote_phase
    str     r0, [r5]
    movs    r0, #ETAT_ARRET_URGENCE
    ldr     r5, =etat
    str     r0, [r5]
    ldr     r5, =compteur_transitions
    ldr     r0, [r5]
    adds    r0, r0, #1
    str     r0, [r5]
    b       fsm_step_sorties

/* B. En urgence : User ignoré (anti-rebond entretenu), acquittement (E8) */
fsm_step_urgence:
    movs    r0, #BTN_USER
    bl      button_pressed
    movs    r0, #BTN_TOUCH
    bl      button_pressed
    cmp     r0, #1
    bne     fsm_step_sorties
    movs    r0, #BTN_ESTOP
    bl      button_raw
    cmp     r0, #0
    bne     fsm_step_sorties        /* E-Stop encore maintenu : refusé       */
    movs    r0, #0
    ldr     r5, =buzzer_continu
    str     r0, [r5]                /* son continu coupé                     */
    ldr     r5, =clignote_compteur
    str     r0, [r5]
    ldr     r5, =clignote_phase
    str     r0, [r5]
    movs    r0, #ETAT_ARRET         /* consigne conservée ; pas de reprise auto */
    bl      fsm_entree_etat

fsm_step_sorties:
    bl      fsm_maj_sorties
    pop     {r4, r5, r6, pc}
    .size   fsm_step, .-fsm_step

/* static void fsm_entree_etat(uint32_t nouvel_etat)
 * Entrée dans ARRÊT / AVANT / ARRIÈRE : etat, transitions, pwm_pct = 0,
 * CCR1 = 0 AVANT tout changement de direction (E3), motor_set_dir selon la
 * table, bip(s) selon la table.                                             */
    .type   fsm_entree_etat, %function
fsm_entree_etat:
    push    {r4, lr}
    mov     r4, r0
    ldr     r1, =etat
    str     r4, [r1]
    ldr     r1, =compteur_transitions
    ldr     r2, [r1]
    adds    r2, r2, #1
    str     r2, [r1]
    movs    r2, #0
    ldr     r1, =pwm_pct
    str     r2, [r1]
    ldr     r1, =rampe_compteur
    str     r2, [r1]
    movs    r0, #0
    bl      motor_set_pwm           /* CCR1 = 0 immédiatement, sans rampe    */
    ldr     r1, =etat_vers_dir
    ldrb    r0, [r1, r4]
    bl      motor_set_dir
    ldr     r1, =etat_nb_bips
    ldrb    r0, [r1, r4]
    bl      buzzer_bip
    pop     {r4, pc}
    .size   fsm_entree_etat, .-fsm_entree_etat

/* static void fsm_maj_sorties(void) — SEUL point de mise à jour des sorties.
 * (1) rampe (AVANT/ARRIÈRE) : 1 point toutes les RAMPE_PAS_MS, vers consigne
 * (2) DEL : fixe d'après l'état ; rouge 2 Hz en urgence
 * (3) buzzer_step                                                           */
    .type   fsm_maj_sorties, %function
fsm_maj_sorties:
    push    {r4, lr}
    ldr     r0, =etat
    ldr     r4, [r0]
    cmp     r4, #ETAT_ARRET_URGENCE
    beq     fsm_maj_clignote
    cmp     r4, #ETAT_ARRET
    beq     fsm_maj_led_normal      /* pas de rampe à l'arrêt                */

    /* (1) rampe */
    ldr     r1, =rampe_compteur
    ldr     r2, [r1]
    adds    r2, r2, #1
    cmp     r2, #RAMPE_PAS_MS
    blo     fsm_maj_rampe_stocke
    movs    r2, #0
    str     r2, [r1]
    ldr     r1, =pwm_pct
    ldr     r2, [r1]
    ldr     r3, =consigne_pct
    ldr     r3, [r3]
    cmp     r2, r3
    beq     fsm_maj_led_normal      /* consigne atteinte                     */
    blo     fsm_maj_monte
    subs    r2, r2, #1              /* descente                              */
    b       fsm_maj_applique
fsm_maj_monte:
    adds    r2, r2, #1              /* montée                                */
fsm_maj_applique:
    str     r2, [r1]
    mov     r0, r2
    bl      motor_set_pwm
    b       fsm_maj_led_normal
fsm_maj_rampe_stocke:
    str     r2, [r1]

    /* (2) DEL fixe */
fsm_maj_led_normal:
    ldr     r1, =etat_vers_del
    ldrb    r0, [r1, r4]
    bl      led_set
    b       fsm_maj_buzzer

    /* (2') clignotement 2 Hz en urgence */
fsm_maj_clignote:
    ldr     r1, =clignote_compteur
    ldr     r2, [r1]
    adds    r2, r2, #1
    cmp     r2, #(CLIGNOTEMENT_DEMI_MS / PERIODE_SCRUTATION_MS)
    blo     fsm_maj_clignote_stocke
    movs    r2, #0
    str     r2, [r1]
    ldr     r3, =clignote_phase
    ldr     r0, [r3]
    eor     r0, r0, #1
    str     r0, [r3]
    b       fsm_maj_clignote_affiche
fsm_maj_clignote_stocke:
    str     r2, [r1]
fsm_maj_clignote_affiche:
    ldr     r3, =clignote_phase
    ldr     r0, [r3]
    cmp     r0, #1
    ite     eq
    moveq   r0, #LED_ROUGE
    movne   r0, #LED_AUCUNE
    bl      led_set

    /* (3) buzzer */
fsm_maj_buzzer:
    bl      buzzer_step
    pop     {r4, pc}
    .size   fsm_maj_sorties, .-fsm_maj_sorties
    .ltorg
