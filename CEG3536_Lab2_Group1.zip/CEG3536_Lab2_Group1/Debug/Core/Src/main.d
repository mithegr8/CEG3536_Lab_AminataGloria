Core/Src/main.o: ../Core/Src/main.s ../Core/Src/registres.inc \
 ../Core/Src/registres_lab2.inc
../Core/Src/registres.inc:
../Core/Src/registres_lab2.inc:
