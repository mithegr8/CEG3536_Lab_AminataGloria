Core/Src/encoder.o: ../Core/Src/encoder.s ../Core/Src/registres.inc \
 ../Core/Src/registres_lab2.inc
../Core/Src/registres.inc:
../Core/Src/registres_lab2.inc:
